export default function NotFoundPage(){
    return <div className="overflow-clip">LLLLOOOAAAAADDDDDDIIIIIINNNNNGGGGG!!!!!!!!!</div>
}