// File path: app/api/promotions/route.ts
// This file automatically creates an API endpoint at the URL `/api/promotions`

import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createClient } from '@/utils/supabase/server';
import prisma from '@/lib/prisma';

// This function handles POST requests to create a new promotion.
export async function POST(request: Request) {
  
  const cookieStore = cookies();
  const supabase = await createClient(cookieStore);

  try {
    // 1. Authenticate the user to ensure they are logged in.
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const user = session.user;

    // 2. Parse the incoming request body to get the promotion details.
    const { content_id, budget, status } = await request.json();

    // --- ADD THIS LOGGING STEP ---
    // This will print the exact data and its type to your server terminal.
    console.log("Received data on server:", { 
      content_id, 
      budget, 
      status, 
      typeOfBudget: typeof budget 
    });

    // --- CORRECTED VALIDATION LOGIC ---
    // Check if budget is a valid number greater than 0.
    if (!content_id || typeof budget !== 'number' || budget <= 0) {
      return NextResponse.json({ error: 'Missing or invalid content_id or budget' }, { status: 400 });
    }

    // 3. Find the content item ONLY IF it belongs to the current user.
    const contentItem = await prisma.content_items.findFirst({
      where: {  
        content_id: content_id,
        websites: { 
          owner_id: user.id,
        },
      },
    });

    // If no item is found, the content doesn't exist OR the user doesn't own it.
    if (!contentItem) {
      return NextResponse.json({ error: 'Forbidden: You do not own this content or it does not exist.' }, { status: 403 });
    }

    // 4. Insert the new record into the 'promotions' table
    const newPromotion = await prisma.promotions.create({
      data: {
        content_id: content_id,
        budget: budget.toString(), // Convert to string for Prisma's Decimal type
        status: status || 'active',
      },
    });

    // 5. Send a success response back to the frontend.
    return NextResponse.json(newPromotion, { status: 201 }); 

  } catch (error) {
    console.error("Failed to create promotion:", error); 
    if (error instanceof Error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
    return NextResponse.json({ error: 'An unknown error occurred' }, { status: 500 });
  }
}

