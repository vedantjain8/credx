// File path: app/api/websites/route.ts
// This file automatically creates an API endpoint at the URL `/api/websites`

import { createClient } from '@/utils/supabase/server';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import prisma from '@/lib/prisma';

// This function handles GET requests to fetch the user's websites.
export async function GET(request: Request) {
  const cookieStore = cookies();
  const supabase = await createClient(cookieStore);

  try {
    // Get the current user's session to identify them.
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Query the 'websites' table to find all sites owned by the current user.
    const websites = await prisma.websites.findMany({
  where: {
    owner_id: session.user.id,
  },
  select: {
    website_id: true,
    domain_name: true,
    status: true,
  },

});


    // Send the list of websites back to the frontend.
    return NextResponse.json  (websites, { status: 200 });

  } catch (error) {
    if (error instanceof Error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
    return NextResponse.json({ error: 'An unknown error occurred' }, { status: 500 });
  }
}
