// File path: app/api/dashboard/wallet/route.ts

import { createClient } from '@/utils/supabase/server';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import prisma from '@/lib/prisma'; // Assuming this is your singleton instance

export async function GET(request: Request) {
    // 1. Create a Supabase client, passing the cookies to it.
    const cookieStore = cookies();
    const supabase = await createClient(cookieStore); // <-- FIX #1: Pass cookieStore, remove await

    try {
        // 2. Get the current user's session data from Supabase.
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (sessionError || !session) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const user = session.user;

        // 3. Query the 'wallets' table to get the user's balance.
        const wallet = await prisma.wallets.findFirst({
            where: {
                user_id: user.id,
            },
            select: {
                wallet_id: true,
                balance: true,
            },
        });

        if (!wallet) {
            return NextResponse.json({ error: 'Wallet not found for this user.' }, { status: 404 });
        }

        // 4. Get the 20 most recent transactions for the wallet.
        const trans = await prisma.transactions.findMany({
            where: {
                OR: [
                    { from_wallet_id: wallet.wallet_id },
                    { to_wallet_id: wallet.wallet_id },
                ],
            },
            orderBy: {
                created_at: 'desc',
            },
            take: 20,
        });

        const responseData = {
            balance: wallet.balance,
            transactions: trans,
        };

        // 5. Return the data with a successful 200 OK status code.
        return NextResponse.json(responseData, { status: 200 }); // <-- FIX #2: Change status to 200

    } catch (error) {
        if (error instanceof Error) {
            return NextResponse.json({ error: error.message }, { status: 500 });
        }
        return NextResponse.json({ error: 'An unknown error occurred' }, { status: 500 });
    }
}