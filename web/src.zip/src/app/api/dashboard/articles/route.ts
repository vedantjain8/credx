import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createClient } from '@/utils/supabase/server';
import prisma from '@/lib/prisma';


export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const cookieStore = cookies();
  const supabase = await createClient(cookieStore);

  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const websiteId = searchParams.get('websiteId');

    if (!websiteId) {
      return NextResponse.json({ error: 'Website ID is required' }, { status: 400 });
    }

   
    const websiteOwner = await prisma.websites.findFirst({
      where: {
        website_id: websiteId,
        owner_id: session.user.id,
      },
      select: {
        website_id: true,
      },
    });

    if (!websiteOwner) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    /
    const articlesFromDb = await prisma.content_items.findMany({
      where: {
        website_id: websiteId,
      },
      select: {
     
        content_id: true, 
        title: true,
        promotions: {
          select: {
            status: true,
            budget: true,
            credits_spent: true,
          },
        },
      },
    });

    
    const articles = articlesFromDb.map(article => ({
      id: article.content_id,
      title: article.title,
      promotions: article.promotions,
    }));


    return NextResponse.json(articles, { status: 200 });

  } catch (error) {
    console.error("Failed to fetch articles:", error);
    return NextResponse.json({ error: 'An unknown error occurred' }, { status: 500 });
  }
}

